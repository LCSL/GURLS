var classgurls_1_1_module =
[
    [ "Module", "da/dd9/classgurls_1_1_module.html#a5a240a8a9ab1813b17bcb810b24ceaea", null ],
    [ "~Module", "da/dd9/classgurls_1_1_module.html#a7c9d9c096786d127590fdd8aa2b7d681", null ],
    [ "eval", "da/dd9/classgurls_1_1_module.html#a345871868ecb3b322299cec765254351", null ],
    [ "train", "da/dd9/classgurls_1_1_module.html#a61a04a3a696cb0ee295a935e407ec862", null ],
    [ "update", "da/dd9/classgurls_1_1_module.html#a1d990a8c64008c36ea19d24fb8a232a8", null ],
    [ "opt", "da/dd9/classgurls_1_1_module.html#a5cdf91e44547b9061831fea443b6002c", null ]
];