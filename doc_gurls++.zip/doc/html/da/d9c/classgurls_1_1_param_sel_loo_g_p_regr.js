var classgurls_1_1_param_sel_loo_g_p_regr =
[
    [ "execute", "da/d9c/classgurls_1_1_param_sel_loo_g_p_regr.html#a03de00a7bfb6a3954471e4fb08f7e351", null ],
    [ "factory", "d8/d85/classgurls_1_1_param_selection.html#a627e4fd41fa3c581c8eac309c32fc29e", null ]
];