var classgurls_1_1_param_sel_ho_primal =
[
    [ "eig_function", "da/d0c/classgurls_1_1_param_sel_ho_primal.html#a15fcb7f1e31693dc20540ed7632532ca", null ],
    [ "execute", "da/d0c/classgurls_1_1_param_sel_ho_primal.html#a0d6adce975ed754ab3a76a1a7f04a566", null ],
    [ "factory", "d8/d85/classgurls_1_1_param_selection.html#a627e4fd41fa3c581c8eac309c32fc29e", null ]
];