var classgurls_1_1_pred_g_p_regr =
[
    [ "execute", "da/d9e/classgurls_1_1_pred_g_p_regr.html#a6de163b5ae890c0b09ceffef68da3ddd", null ],
    [ "factory", "d7/d57/classgurls_1_1_prediction.html#a1ddacf8a2757aab38d1e4b564526571a", null ]
];