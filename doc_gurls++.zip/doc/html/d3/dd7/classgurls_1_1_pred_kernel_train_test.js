var classgurls_1_1_pred_kernel_train_test =
[
    [ "execute", "d3/dd7/classgurls_1_1_pred_kernel_train_test.html#ad9ea7a49b769e20aada15fb1d7a4f0e4", null ],
    [ "factory", "d1/d99/classgurls_1_1_pred_kernel.html#ae9d54c93c34ed89919ca1dc72092e602", null ]
];