var classgurls_1_1_param_sel_loocv_primal =
[
    [ "execute", "d3/d1d/classgurls_1_1_param_sel_loocv_primal.html#ad2e616a3e56cc97ab6edb45fcde9d3ca", null ],
    [ "factory", "d8/d85/classgurls_1_1_param_selection.html#a627e4fd41fa3c581c8eac309c32fc29e", null ]
];