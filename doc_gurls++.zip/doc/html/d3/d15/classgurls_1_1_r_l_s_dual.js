var classgurls_1_1_r_l_s_dual =
[
    [ "execute", "d3/d15/classgurls_1_1_r_l_s_dual.html#ad7fb40a3e66cf1b2af1e7ebd9510fe0b", null ],
    [ "factory", "d6/ddf/classgurls_1_1_optimizer.html#a9470360032168e3208f4aa0c1ee05e86", null ]
];