var classgurls_1_1_opt_matrix_base =
[
    [ "MatrixType", "d3/dfe/classgurls_1_1_opt_matrix_base.html#a6af16d68562e1aaa340c96bc43403efc", null ],
    [ "OptMatrixBase", "d3/dfe/classgurls_1_1_opt_matrix_base.html#ae569d19b625c9a97ac304893e9205a0a", null ],
    [ "getDataID", "d5/dcc/classgurls_1_1_gurls_option.html#a431323a19e055d3153e22a1871afb50d", null ],
    [ "getMatrixType", "d3/dfe/classgurls_1_1_opt_matrix_base.html#a03a5d5a0cece057f6ea8c6f32e039dd0", null ],
    [ "getType", "d5/dcc/classgurls_1_1_gurls_option.html#a0d920a9a0956c273d2f5898de912f1a6", null ],
    [ "isA", "d5/dcc/classgurls_1_1_gurls_option.html#a2ba865a44888821e726f88e087bc60f6", null ],
    [ "operator<<", "d5/dcc/classgurls_1_1_gurls_option.html#aaa798e1552e96f68e358ec5a89ee7500", null ],
    [ "operator<<", "d5/dcc/classgurls_1_1_gurls_option.html#ab8ca962235eb774ea2c322df52f50afd", null ],
    [ "matType", "d3/dfe/classgurls_1_1_opt_matrix_base.html#a0c70f9146433e3a823cb3d36f8f8b3f1", null ],
    [ "type", "d5/dcc/classgurls_1_1_gurls_option.html#aea0687b6adb753e8693061721142905d", null ]
];