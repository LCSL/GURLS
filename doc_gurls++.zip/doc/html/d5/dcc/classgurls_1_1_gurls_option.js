var classgurls_1_1_gurls_option =
[
    [ "GurlsOption", "d5/dcc/classgurls_1_1_gurls_option.html#a45831ee046165c41183a8d810f56e08a", null ],
    [ "~GurlsOption", "d5/dcc/classgurls_1_1_gurls_option.html#a33a9b28af21f2cd1cd5f162af1b79db3", null ],
    [ "getDataID", "d5/dcc/classgurls_1_1_gurls_option.html#a431323a19e055d3153e22a1871afb50d", null ],
    [ "getType", "d5/dcc/classgurls_1_1_gurls_option.html#a0d920a9a0956c273d2f5898de912f1a6", null ],
    [ "isA", "d5/dcc/classgurls_1_1_gurls_option.html#a2ba865a44888821e726f88e087bc60f6", null ],
    [ "operator<<", "d5/dcc/classgurls_1_1_gurls_option.html#aaa798e1552e96f68e358ec5a89ee7500", null ],
    [ "operator<<", "d5/dcc/classgurls_1_1_gurls_option.html#ab8ca962235eb774ea2c322df52f50afd", null ],
    [ "type", "d5/dcc/classgurls_1_1_gurls_option.html#aea0687b6adb753e8693061721142905d", null ]
];