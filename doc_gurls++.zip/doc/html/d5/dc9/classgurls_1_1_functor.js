var classgurls_1_1_functor =
[
    [ "operator()", "d5/dc9/classgurls_1_1_functor.html#abd5a0c4e400d0f0b59c8f3139d0286e9", null ],
    [ "operator()", "d5/dc9/classgurls_1_1_functor.html#ab9cb1b4386f8b9b68e375cd96f6d4859", null ]
];