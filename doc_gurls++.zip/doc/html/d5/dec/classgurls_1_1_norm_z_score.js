var classgurls_1_1_norm_z_score =
[
    [ "execute", "d5/dec/classgurls_1_1_norm_z_score.html#aedfaaf81f55c402a7924b85424b1499b", null ],
    [ "factory", "d9/d56/classgurls_1_1_norm.html#a6de8719538c5f134ce611489b5578a59", null ]
];