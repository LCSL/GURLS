var classgurls_1_1_optimizer =
[
    [ "execute", "d6/ddf/classgurls_1_1_optimizer.html#a2b13d7accfa26e838280455bda27d7ab", null ],
    [ "factory", "d6/ddf/classgurls_1_1_optimizer.html#a9470360032168e3208f4aa0c1ee05e86", null ]
];