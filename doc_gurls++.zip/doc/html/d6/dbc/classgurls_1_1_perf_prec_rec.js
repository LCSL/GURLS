var classgurls_1_1_perf_prec_rec =
[
    [ "execute", "d6/dbc/classgurls_1_1_perf_prec_rec.html#ac3d5fc2d89ba5c4a1db5a5b5c63c3af4", null ],
    [ "factory", "d5/dac/classgurls_1_1_performance.html#af45e9e3b96f97d345c8c8b8ff9e92552", null ]
];