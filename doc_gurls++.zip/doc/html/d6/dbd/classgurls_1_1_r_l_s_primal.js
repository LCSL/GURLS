var classgurls_1_1_r_l_s_primal =
[
    [ "execute", "d6/dbd/classgurls_1_1_r_l_s_primal.html#ab25c8db5a8141e5186f224c365fc85e4", null ],
    [ "factory", "d6/ddf/classgurls_1_1_optimizer.html#a9470360032168e3208f4aa0c1ee05e86", null ]
];