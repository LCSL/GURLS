var classgurls_1_1_param_sel_siglam =
[
    [ "execute", "d6/d3a/classgurls_1_1_param_sel_siglam.html#a42c98adae6811cd7db79444dce371984", null ],
    [ "factory", "d8/d85/classgurls_1_1_param_selection.html#a627e4fd41fa3c581c8eac309c32fc29e", null ]
];