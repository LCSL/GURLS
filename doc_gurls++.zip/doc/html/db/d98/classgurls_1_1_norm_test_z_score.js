var classgurls_1_1_norm_test_z_score =
[
    [ "execute", "db/d98/classgurls_1_1_norm_test_z_score.html#af47944eb30e4f790bf0a50437f671dbc", null ],
    [ "factory", "d9/d56/classgurls_1_1_norm.html#a6de8719538c5f134ce611489b5578a59", null ]
];