var classgurls_1_1_norm_l2 =
[
    [ "execute", "db/d42/classgurls_1_1_norm_l2.html#a013f75e2461919132ca3bb3a0525bd81", null ],
    [ "factory", "d9/d56/classgurls_1_1_norm.html#a6de8719538c5f134ce611489b5578a59", null ]
];