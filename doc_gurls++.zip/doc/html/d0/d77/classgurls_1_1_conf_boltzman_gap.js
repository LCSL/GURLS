var classgurls_1_1_conf_boltzman_gap =
[
    [ "execute", "d0/d77/classgurls_1_1_conf_boltzman_gap.html#ac294a259ffed639748df91b64211eee5", null ],
    [ "factory", "da/d7d/classgurls_1_1_confidence.html#af86adf5cf4608cf95056029e6f979500", null ]
];