var classgurls_1_1_param_sel_ho_dualr =
[
    [ "eig_function", "d0/d9b/classgurls_1_1_param_sel_ho_dualr.html#a2cb39175e10be1412969379ad5278a98", null ],
    [ "execute", "de/dc2/classgurls_1_1_param_sel_ho_dual.html#a96b0eb5b18cb1b7ca6c7462c39f85fa6", null ],
    [ "factory", "d8/d85/classgurls_1_1_param_selection.html#a627e4fd41fa3c581c8eac309c32fc29e", null ],
    [ "getRank", "d0/d9b/classgurls_1_1_param_sel_ho_dualr.html#a752ff96bb743a31b8d97ad4a2174b1ed", null ]
];