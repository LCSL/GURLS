var classgurls_1_1_param_sel_siglam_loo_g_p_regr =
[
    [ "execute", "d0/d75/classgurls_1_1_param_sel_siglam_loo_g_p_regr.html#a2a83bad4e0d96b196edde502ed9878a2", null ],
    [ "factory", "d8/d85/classgurls_1_1_param_selection.html#a627e4fd41fa3c581c8eac309c32fc29e", null ]
];