var classgurls_1_1_kernel_r_b_f =
[
    [ "execute", "d0/d97/classgurls_1_1_kernel_r_b_f.html#a95d2390382b2bc443ef88eccb6c61cab", null ],
    [ "factory", "dc/d0c/classgurls_1_1_kernel.html#a502a6236b98389f61b3f0affbcf027f8", null ]
];