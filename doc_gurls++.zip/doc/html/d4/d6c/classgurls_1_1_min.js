var classgurls_1_1_min =
[
    [ "operator()", "d4/d6c/classgurls_1_1_min.html#abe6e0ac5657864799a0238758de61731", null ],
    [ "operator()", "d4/d6c/classgurls_1_1_min.html#a9717c235dc070d34d0cde381d3f92513", null ]
];