var classgurls_1_1_r_l_s_g_p_regr =
[
    [ "execute", "d4/db3/classgurls_1_1_r_l_s_g_p_regr.html#ab72b8b676be7249b2efb84fc8c10fa0c", null ],
    [ "factory", "d6/ddf/classgurls_1_1_optimizer.html#a9470360032168e3208f4aa0c1ee05e86", null ]
];