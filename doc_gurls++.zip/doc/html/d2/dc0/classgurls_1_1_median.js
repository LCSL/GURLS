var classgurls_1_1_median =
[
    [ "median", "d2/dc0/classgurls_1_1_median.html#abb8695a97377a9e0fe1750a0c53fc32a", null ],
    [ "operator()", "d2/dc0/classgurls_1_1_median.html#a708fef4cf84017647ebf995468df7382", null ],
    [ "operator()", "d2/dc0/classgurls_1_1_median.html#ac0701a6115eada3c8a2e0e49b2f29fb2", null ]
];