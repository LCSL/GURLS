var classgurls_1_1_mean =
[
    [ "mean", "d2/de4/classgurls_1_1_mean.html#a61cdf54c41e0477e034d888d938c7751", null ],
    [ "operator()", "d2/de4/classgurls_1_1_mean.html#ad1b60dd5afd633c93ee11c3f662b1d43", null ],
    [ "operator()", "d2/de4/classgurls_1_1_mean.html#a6dbd0da165f53ab5a1846d83b5b7544e", null ]
];