var classgurls_1_1_r_l_s_primal_rec_init =
[
    [ "execute", "d2/d8f/classgurls_1_1_r_l_s_primal_rec_init.html#ac655256a83b0b503e4985273986de5a7", null ],
    [ "factory", "d6/ddf/classgurls_1_1_optimizer.html#a9470360032168e3208f4aa0c1ee05e86", null ]
];