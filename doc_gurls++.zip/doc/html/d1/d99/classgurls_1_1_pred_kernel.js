var classgurls_1_1_pred_kernel =
[
    [ "execute", "d1/d99/classgurls_1_1_pred_kernel.html#a220dbb68a5d8ec0c97e8a2725e12f82b", null ],
    [ "factory", "d1/d99/classgurls_1_1_pred_kernel.html#ae9d54c93c34ed89919ca1dc72092e602", null ]
];