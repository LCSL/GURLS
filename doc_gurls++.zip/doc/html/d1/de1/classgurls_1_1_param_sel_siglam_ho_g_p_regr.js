var classgurls_1_1_param_sel_siglam_ho_g_p_regr =
[
    [ "execute", "d1/de1/classgurls_1_1_param_sel_siglam_ho_g_p_regr.html#a055ca69a226e6cea654eaabfc9866714", null ],
    [ "factory", "d8/d85/classgurls_1_1_param_selection.html#a627e4fd41fa3c581c8eac309c32fc29e", null ]
];