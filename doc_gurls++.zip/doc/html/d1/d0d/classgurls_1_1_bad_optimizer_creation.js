var classgurls_1_1_bad_optimizer_creation =
[
    [ "BadOptimizerCreation", "d1/d0d/classgurls_1_1_bad_optimizer_creation.html#a0dc6b04d9370ac1d962bd864c0e07882", null ]
];