var classgurls_1_1_norm =
[
    [ "execute", "d9/d56/classgurls_1_1_norm.html#adb0c2d37b221ec2f5b94e8643d33f7c8", null ],
    [ "factory", "d9/d56/classgurls_1_1_norm.html#a6de8719538c5f134ce611489b5578a59", null ]
];