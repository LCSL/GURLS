var classgurls_1_1_r_l_s_dualr =
[
    [ "execute", "d9/d3f/classgurls_1_1_r_l_s_dualr.html#a633228bef1d86697cc39ecfdd1a84e39", null ],
    [ "factory", "d6/ddf/classgurls_1_1_optimizer.html#a9470360032168e3208f4aa0c1ee05e86", null ]
];