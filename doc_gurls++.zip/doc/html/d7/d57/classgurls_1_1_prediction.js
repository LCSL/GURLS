var classgurls_1_1_prediction =
[
    [ "execute", "d7/d57/classgurls_1_1_prediction.html#a62f1d84e083b4d619ee7c342f9d6b855", null ],
    [ "factory", "d7/d57/classgurls_1_1_prediction.html#a1ddacf8a2757aab38d1e4b564526571a", null ]
];