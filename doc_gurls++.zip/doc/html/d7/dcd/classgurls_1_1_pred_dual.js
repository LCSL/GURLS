var classgurls_1_1_pred_dual =
[
    [ "execute", "d7/dcd/classgurls_1_1_pred_dual.html#a81035892d1dac2d07c221b133570293a", null ],
    [ "factory", "d7/d57/classgurls_1_1_prediction.html#a1ddacf8a2757aab38d1e4b564526571a", null ]
];