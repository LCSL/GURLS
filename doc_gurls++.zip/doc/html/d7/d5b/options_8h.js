var options_8h =
[
    [ "OptTypes", "db/d4e/namespacegurls.html#a48a64fe4489faef6c626e2c132495b89", null ],
    [ "TASKDESC_SEPARATOR", "db/d4e/namespacegurls.html#a2270d88158df11a01a89f70dead4986c", null ]
];