var searchData=
[
  ['l0norm',['L0norm',['../db/d4e/namespacegurls.html#a43e8662fd4f3931c97a53a9547bee45c',1,'gurls']]],
  ['l1norm',['L1norm',['../db/d4e/namespacegurls.html#af5bf9b9d001587d568e3a297f053f35d',1,'gurls']]],
  ['l2norm',['L2norm',['../db/d4e/namespacegurls.html#a3725a490ac50d56cabf19833d2255341',1,'gurls']]],
  ['less',['Less',['../d1/d9e/classgurls_1_1g_mat2_d.html#a27e562f974a67c03284d298a2da35909',1,'gurls::gMat2D']]],
  ['lesseq',['LessEq',['../d1/d9e/classgurls_1_1g_mat2_d.html#a2c2cdb9fc0ae969ad2a9ec69472045cb',1,'gurls::gMat2D']]],
  ['linfnorm',['LInfnorm',['../db/d4e/namespacegurls.html#aa7d778719a779aebd251350924f63daa',1,'gurls']]]
];
