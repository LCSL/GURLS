var searchData=
[
  ['dot',['dot',['../d1/d9e/classgurls_1_1g_mat2_d.html#a35464b1e260eb29481ecaa0173c64bc0',1,'gurls::gMat2D::dot()'],['../d1/d9e/classgurls_1_1g_mat2_d.html#a10ea05e25bc9180157522a9f3295adff',1,'gurls::gMat2D::dot()']]]
];
