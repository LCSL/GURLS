var searchData=
[
  ['actionnames',['actionNames',['../db/d52/classgurls_1_1_opt_process.html#a334e21a77e7adb4f28ccf285d46465c7',1,'gurls::OptProcess']]],
  ['add',['add',['../d9/d8b/classgurls_1_1_base_array.html#a100cf2d14f7d0a43549cc4f98a50af15',1,'gurls::BaseArray::add()'],['../d7/da3/classgurls_1_1_opt_string_list.html#af76634b4ca30e337b762c8c90c73a5e5',1,'gurls::OptStringList::add()'],['../df/dda/classgurls_1_1_opt_number_list.html#aa71ec7869adfc3b7c157aca61171ca49',1,'gurls::OptNumberList::add()']]],
  ['addaction',['addAction',['../db/d52/classgurls_1_1_opt_process.html#adf2b1ddf0276a4cce2ed5cf32f3adbfa',1,'gurls::OptProcess']]],
  ['addopt',['addOpt',['../dc/d34/classgurls_1_1_gurls_options_list.html#a93430579dc5f429ccc16106a7e643b69',1,'gurls::GurlsOptionsList::addOpt(std::string key, GurlsOption *value)'],['../dc/d34/classgurls_1_1_gurls_options_list.html#ad35d576ce92fcd61443f62f051f8d010',1,'gurls::GurlsOptionsList::addOpt(std::string key, std::string value)'],['../dc/d34/classgurls_1_1_gurls_options_list.html#a7805dedb8d3bb41f9c8fb0852d49a99a',1,'gurls::GurlsOptionsList::addOpt(std::string key, std::wstring value)']]],
  ['addtask',['addTask',['../dc/d25/classgurls_1_1_opt_task_sequence.html#a258e59833052fb156864001d118c7d16',1,'gurls::OptTaskSequence']]],
  ['allequalsto',['allEqualsTo',['../d1/d9e/classgurls_1_1g_mat2_d.html#aeb8f831928ff7ccb3ec2f2d15b36198a',1,'gurls::gMat2D']]],
  ['alloc',['alloc',['../d9/d8b/classgurls_1_1_base_array.html#ab0ab43323ff1ff466e3cab51f5c58d92',1,'gurls::BaseArray']]],
  ['argmax',['argmax',['../d1/d9e/classgurls_1_1g_mat2_d.html#a27b604f5e7bc62af1e6c5510dcb5a9fb',1,'gurls::gMat2D::argmax()'],['../df/d32/classgurls_1_1g_vec.html#a7ee61687fdc2d7162c467201ac23893e',1,'gurls::gVec::argmax()']]],
  ['argmin',['argmin',['../d1/d9e/classgurls_1_1g_mat2_d.html#ad6e7cf1658da5d3741ae4864453ed67b',1,'gurls::gMat2D::argmin()'],['../df/d32/classgurls_1_1g_vec.html#a369b4d89ddeed8353c2464c9c2a11f7b',1,'gurls::gVec::argmin()'],['../db/d4e/namespacegurls.html#ae7290ab4b6cd018d525178cf2f740fba',1,'gurls::argmin()']]],
  ['asarray',['asarray',['../d9/d8b/classgurls_1_1_base_array.html#a7d7bbbbaefa0de4777023a8db0d9b43c',1,'gurls::BaseArray']]],
  ['asmatrix',['asMatrix',['../df/d32/classgurls_1_1g_vec.html#a24148f154348fbd25c2fd7ab18c86690',1,'gurls::gVec']]],
  ['asvector',['asvector',['../d1/d9e/classgurls_1_1g_mat2_d.html#ab75c6a0e2ee9b20cebb590fec3d8fe88',1,'gurls::gMat2D']]],
  ['at',['at',['../df/d32/classgurls_1_1g_vec.html#a2efbc02be5a2b544473aeb23011493ef',1,'gurls::gVec::at(unsigned long i) const '],['../df/d32/classgurls_1_1g_vec.html#a678ffbabae6f2e0ddeaabaf8c5dd41ec',1,'gurls::gVec::at(unsigned long i)']]],
  ['axpy',['axpy',['../db/d4e/namespacegurls.html#a82ee9c80ec97ed26a84b7d311a2cef76',1,'gurls::axpy(const int N, const T alpha, const T *X, const int incX, T *Y, const int incY)'],['../db/d4e/namespacegurls.html#a93392e818a249bdc64e3e1b391847948',1,'gurls::axpy(const int N, const float alpha, const float *X, const int incX, float *Y, const int incY)'],['../db/d4e/namespacegurls.html#ab2de64ae5dbab4cc0415429c1d4a8456',1,'gurls::axpy(const int N, const double alpha, const double *X, const int incX, double *Y, const int incY)']]]
];
