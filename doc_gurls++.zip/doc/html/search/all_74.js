var searchData=
[
  ['table',['table',['../dc/d34/classgurls_1_1_gurls_options_list.html#afaaf60920252145fad8c4eae8c06e4fd',1,'gurls::GurlsOptionsList']]],
  ['taskdesc_5fseparator',['TASKDESC_SEPARATOR',['../db/d4e/namespacegurls.html#a2270d88158df11a01a89f70dead4986c',1,'gurls']]],
  ['test_5fclassifier',['test_classifier',['../db/d4e/namespacegurls.html#ade3f4598bd1adbc6b009209aa409635e',1,'gurls']]],
  ['tostring',['toString',['../dc/d34/classgurls_1_1_gurls_options_list.html#ae3ae1e5a5a967145304bb08bf3d18a44',1,'gurls::GurlsOptionsList']]],
  ['transpose',['transpose',['../d1/d9e/classgurls_1_1g_mat2_d.html#a278e0dcc7cd8b648e04426fa35c829f0',1,'gurls::gMat2D::transpose()'],['../db/d4e/namespacegurls.html#a6d60c6fa2a1a6336ebf51e9adfbf3d7e',1,'gurls::transpose()']]],
  ['trsm',['trsm',['../db/d4e/namespacegurls.html#a736d5bda0bca8dff4586fc1de89eedc9',1,'gurls::trsm(const CBLAS_SIDE Side, const CBLAS_UPLO Uplo, const CBLAS_TRANSPOSE TransA, const CBLAS_DIAG Diag, const int M, const int N, const T alpha, const T *A, const int lda, T *B, const int ldb)'],['../db/d4e/namespacegurls.html#a5aaba5d222dfc54fbeed11af7b1175b8',1,'gurls::trsm(const CBLAS_SIDE Side, const CBLAS_UPLO Uplo, const CBLAS_TRANSPOSE TransA, const CBLAS_DIAG Diag, const int M, const int N, const float alpha, const float *A, const int lda, float *B, const int ldb)'],['../db/d4e/namespacegurls.html#a130348dfd1df52f06b44742b9ee6bd25',1,'gurls::trsm(const CBLAS_SIDE Side, const CBLAS_UPLO Uplo, const CBLAS_TRANSPOSE TransA, const CBLAS_DIAG Diag, const int M, const int N, const double alpha, const double *A, const int lda, double *B, const int ldb)']]],
  ['type',['type',['../d5/dcc/classgurls_1_1_gurls_option.html#aea0687b6adb753e8693061721142905d',1,'gurls::GurlsOption']]]
];
