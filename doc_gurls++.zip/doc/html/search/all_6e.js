var searchData=
[
  ['name',['name',['../d8/d4b/classgurls_1_1_opt_function.html#a6658e20402099367e9d1376201f661f1',1,'gurls::OptFunction::name()'],['../dc/d34/classgurls_1_1_gurls_options_list.html#ab2c515136d45f9f2caa69051cef75cc3',1,'gurls::GurlsOptionsList::name()']]],
  ['nonzeros',['nonzeros',['../df/d32/classgurls_1_1g_vec.html#afc28b0cb66b8c807b41def4a3e7b3faf',1,'gurls::gVec']]],
  ['norm',['Norm',['../d9/d56/classgurls_1_1_norm.html',1,'gurls']]],
  ['norm',['norm',['../db/d4e/namespacegurls.html#af37cded61440c0f4c5e6b121e32f1961',1,'gurls::norm(const gVec&lt; T &gt; &amp;x, std::string type=&quot;l2&quot;)'],['../db/d4e/namespacegurls.html#aede1544769680472b68e7a4c6dffcd37',1,'gurls::norm(const gMat2D&lt; T &gt; &amp;A, std::string type=&quot;l2&quot;)']]],
  ['norml2',['NormL2',['../db/d42/classgurls_1_1_norm_l2.html',1,'gurls']]],
  ['normtestzscore',['NormTestZScore',['../db/d98/classgurls_1_1_norm_test_z_score.html',1,'gurls']]],
  ['normzscore',['NormZScore',['../d5/dec/classgurls_1_1_norm_z_score.html',1,'gurls']]],
  ['nrm2',['nrm2',['../db/d4e/namespacegurls.html#afc7fa72c121304f29f5a4f6ea6874994',1,'gurls::nrm2(const int N, const T *X, const int incX)'],['../db/d4e/namespacegurls.html#ab8235c30a1bb018e0e5fcd70b9184018',1,'gurls::nrm2(const int N, const float *X, const int incX)'],['../db/d4e/namespacegurls.html#a97ab036038ecb33220118ce805cc7f10',1,'gurls::nrm2(const int N, const double *X, const int incX)']]],
  ['numcols',['numcols',['../d1/d9e/classgurls_1_1g_mat2_d.html#af1b2d959be0839e7a13a54d712ed3c96',1,'gurls::gMat2D']]],
  ['numrows',['numrows',['../d1/d9e/classgurls_1_1g_mat2_d.html#a0a969acab425fe89d05f86367b48462b',1,'gurls::gMat2D']]]
];
