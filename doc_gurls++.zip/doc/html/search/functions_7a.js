var searchData=
[
  ['zeros',['zeros',['../d1/d9e/classgurls_1_1g_mat2_d.html#ab7741da10c60c786794f4d6a64cf6286',1,'gurls::gMat2D::zeros()'],['../df/d32/classgurls_1_1g_vec.html#a50689ff1ae15d56fc3519dc5233808a1',1,'gurls::gVec::zeros()']]]
];
