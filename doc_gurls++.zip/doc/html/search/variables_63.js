var searchData=
[
  ['columnwise',['COLUMNWISE',['../db/d4e/namespacegurls.html#aaf6481f6844f82fc3f44119d2d47158a',1,'gurls']]]
];
