var searchData=
[
  ['l0norm',['L0norm',['../db/d4e/namespacegurls.html#a43e8662fd4f3931c97a53a9547bee45c',1,'gurls']]],
  ['l1norm',['L1norm',['../db/d4e/namespacegurls.html#af5bf9b9d001587d568e3a297f053f35d',1,'gurls']]],
  ['l2norm',['L2norm',['../db/d4e/namespacegurls.html#a3725a490ac50d56cabf19833d2255341',1,'gurls']]],
  ['lambdaguesses',['lambdaguesses',['../db/d4e/namespacegurls.html#a68355fb1c541564d3179538285d4673a',1,'gurls']]],
  ['le',['le',['../db/d4e/namespacegurls.html#a141eeb37a2b25f93bfcde3453641dc8c',1,'gurls']]],
  ['less',['Less',['../d1/d9e/classgurls_1_1g_mat2_d.html#a27e562f974a67c03284d298a2da35909',1,'gurls::gMat2D']]],
  ['lesseq',['LessEq',['../d1/d9e/classgurls_1_1g_mat2_d.html#a2c2cdb9fc0ae969ad2a9ec69472045cb',1,'gurls::gMat2D']]],
  ['linfnorm',['LInfnorm',['../db/d4e/namespacegurls.html#aa7d778719a779aebd251350924f63daa',1,'gurls']]],
  ['linspace',['linspace',['../db/d4e/namespacegurls.html#a3d21517d1d6205fe9b6da238bb7348af',1,'gurls']]],
  ['load',['load',['../d9/d8b/classgurls_1_1_base_array.html#a3be7039b5968bcadf3a26c0dd78a5607',1,'gurls::BaseArray::load()'],['../d1/d9e/classgurls_1_1g_mat2_d.html#a1becc28277bdd21185fafb44e263f24c',1,'gurls::gMat2D::load(Archive &amp;, const unsigned int)'],['../d1/d9e/classgurls_1_1g_mat2_d.html#afceb332893e4bf72d6b7be1a3959affb',1,'gurls::gMat2D::load(const std::string &amp;fileName)'],['../da/d90/classgurls_1_1_opt_array.html#ad34045b0923bad8c8c2418d06e5966dd',1,'gurls::OptArray::load()'],['../dc/d34/classgurls_1_1_gurls_options_list.html#a496536defe8447d982a4799c1db8cdbd',1,'gurls::GurlsOptionsList::load()']]],
  ['lowertriangular',['lowertriangular',['../d1/d9e/classgurls_1_1g_mat2_d.html#af4f995eefb4060a9ab0ddd5cdf917856',1,'gurls::gMat2D']]],
  ['lt',['lt',['../db/d4e/namespacegurls.html#a57330e9148465f7dad58b80361e4b510',1,'gurls::lt(T a, T b)'],['../db/d4e/namespacegurls.html#a2881d6d5ce35586ea88b6b485f6afa3a',1,'gurls::lt(float a, float b)'],['../db/d4e/namespacegurls.html#a710b4faef3dc85d1e07dd6bdfbe78b30',1,'gurls::lt(double a, double b)']]],
  ['ltcompare',['LtCompare',['../d0/db4/classgurls_1_1_lt_compare.html',1,'gurls']]],
  ['lu',['lu',['../db/d4e/namespacegurls.html#a2aea606f269de6a897bcfda5a11897b6',1,'gurls::lu(gMat2D&lt; T &gt; &amp;A)'],['../db/d4e/namespacegurls.html#a73da67aa7117e56d52b5a88759cf3d78',1,'gurls::lu(gMat2D&lt; T &gt; &amp;A, gVec&lt; int &gt; &amp;pv)'],['../db/d4e/namespacegurls.html#a97d0945c7e119434e9941fd2af1636ed',1,'gurls::lu(gMat2D&lt; float &gt; &amp;A, gVec&lt; int &gt; &amp;pv)'],['../db/d4e/namespacegurls.html#ae1cfdeee30ddb12b831944630f918cf4',1,'gurls::lu(gMat2D&lt; float &gt; &amp;A)']]]
];
