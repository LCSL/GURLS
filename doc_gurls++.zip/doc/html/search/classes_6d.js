var searchData=
[
  ['max',['Max',['../dd/de1/classgurls_1_1_max.html',1,'gurls']]],
  ['mean',['Mean',['../d2/de4/classgurls_1_1_mean.html',1,'gurls']]],
  ['median',['Median',['../d2/dc0/classgurls_1_1_median.html',1,'gurls']]],
  ['min',['Min',['../d4/d6c/classgurls_1_1_min.html',1,'gurls']]],
  ['module',['Module',['../da/dd9/classgurls_1_1_module.html',1,'gurls']]]
];
