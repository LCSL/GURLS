var searchData=
[
  ['name',['name',['../d8/d4b/classgurls_1_1_opt_function.html#a6658e20402099367e9d1376201f661f1',1,'gurls::OptFunction::name()'],['../dc/d34/classgurls_1_1_gurls_options_list.html#ab2c515136d45f9f2caa69051cef75cc3',1,'gurls::GurlsOptionsList::name()']]],
  ['numcols',['numcols',['../d1/d9e/classgurls_1_1g_mat2_d.html#af1b2d959be0839e7a13a54d712ed3c96',1,'gurls::gMat2D']]],
  ['numrows',['numrows',['../d1/d9e/classgurls_1_1g_mat2_d.html#a0a969acab425fe89d05f86367b48462b',1,'gurls::gMat2D']]]
];
