var searchData=
[
  ['functor',['Functor',['../d5/dc9/classgurls_1_1_functor.html',1,'gurls']]]
];
