var searchData=
[
  ['macroavg',['macroavg',['../d8/dc8/classgurls_1_1_perf_macro_avg.html#a9b6c4cebbfc043f647a4fd8456c1e5ab',1,'gurls::PerfMacroAvg']]],
  ['matrixtype',['MatrixType',['../d3/dfe/classgurls_1_1_opt_matrix_base.html#a6af16d68562e1aaa340c96bc43403efc',1,'gurls::OptMatrixBase']]],
  ['mattype',['matType',['../d3/dfe/classgurls_1_1_opt_matrix_base.html#a0c70f9146433e3a823cb3d36f8f8b3f1',1,'gurls::OptMatrixBase']]],
  ['max',['max',['../d9/d8b/classgurls_1_1_base_array.html#a5891241bf8c1f60ab1487656a145626f',1,'gurls::BaseArray::max()'],['../d1/d9e/classgurls_1_1g_mat2_d.html#a434c3272592f4014f10f55a4fabcca25',1,'gurls::gMat2D::max()']]],
  ['max',['Max',['../dd/de1/classgurls_1_1_max.html',1,'gurls']]],
  ['max_5fprintable_5fsize',['MAX_PRINTABLE_SIZE',['../db/d4e/namespacegurls.html#a11d0fc7949708ef68897305433953b8b',1,'gurls']]],
  ['maxvalues',['maxValues',['../db/d4e/namespacegurls.html#a32e6ab8c84d4bee2f94efedc5e8ea53a',1,'gurls']]],
  ['mean',['Mean',['../d2/de4/classgurls_1_1_mean.html',1,'gurls']]],
  ['mean',['mean',['../db/d4e/namespacegurls.html#a85151ab18d29196f25627917c9526088',1,'gurls']]],
  ['median',['median',['../db/d4e/namespacegurls.html#aaf1db63a5209152b935c2fbc7b7f8352',1,'gurls::median(T *v, const int length)'],['../db/d4e/namespacegurls.html#ac6c7c43939ffdc334083440d0d4b84ea',1,'gurls::median(const T *M, const int rows, const int cols, const int dimension, T *res, T *work)']]],
  ['median',['Median',['../d2/dc0/classgurls_1_1_median.html',1,'gurls']]],
  ['min',['Min',['../d4/d6c/classgurls_1_1_min.html',1,'gurls']]],
  ['min',['min',['../d9/d8b/classgurls_1_1_base_array.html#a2b4aff4d0c76fda6a84cab2734ef602b',1,'gurls::BaseArray::min()'],['../d1/d9e/classgurls_1_1g_mat2_d.html#acd77ab95207f281ec8d12ef740213258',1,'gurls::gMat2D::min()']]],
  ['mldivide_5fsquared',['mldivide_squared',['../db/d4e/namespacegurls.html#aa4cf57d556e713079f9f556a0951486e',1,'gurls']]],
  ['module',['Module',['../da/dd9/classgurls_1_1_module.html',1,'gurls']]],
  ['msg',['msg',['../d1/d29/classgurls_1_1g_exception.html#a11b8f8e8341d91318af8299862034cee',1,'gurls::gException']]],
  ['mul',['mul',['../db/d4e/namespacegurls.html#ac6b4396e2c97744191760e762697ae46',1,'gurls']]],
  ['mult',['mult',['../db/d4e/namespacegurls.html#a43a5eeef1874c15e091086b62cfcaebd',1,'gurls']]],
  ['multiply',['multiply',['../d9/d8b/classgurls_1_1_base_array.html#abac614d73132b3974c2341d8038d7384',1,'gurls::BaseArray']]]
];
