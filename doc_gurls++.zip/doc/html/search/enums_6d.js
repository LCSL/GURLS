var searchData=
[
  ['matrixtype',['MatrixType',['../d3/dfe/classgurls_1_1_opt_matrix_base.html#a6af16d68562e1aaa340c96bc43403efc',1,'gurls::OptMatrixBase']]]
];
