var searchData=
[
  ['kernel',['Kernel',['../dc/d0c/classgurls_1_1_kernel.html',1,'gurls']]],
  ['kernelchisquared',['KernelChisquared',['../dc/d82/classgurls_1_1_kernel_chisquared.html',1,'gurls']]],
  ['kernellinear',['KernelLinear',['../d8/d84/classgurls_1_1_kernel_linear.html',1,'gurls']]],
  ['kernelrbf',['KernelRBF',['../d0/d97/classgurls_1_1_kernel_r_b_f.html',1,'gurls']]]
];
