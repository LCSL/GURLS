var searchData=
[
  ['isowner',['isowner',['../d9/d8b/classgurls_1_1_base_array.html#a78e709d308cb750f4ae822d3e2f8ce81',1,'gurls::BaseArray']]]
];
