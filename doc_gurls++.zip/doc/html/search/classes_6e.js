var searchData=
[
  ['norm',['Norm',['../d9/d56/classgurls_1_1_norm.html',1,'gurls']]],
  ['norml2',['NormL2',['../db/d42/classgurls_1_1_norm_l2.html',1,'gurls']]],
  ['normtestzscore',['NormTestZScore',['../db/d98/classgurls_1_1_norm_test_z_score.html',1,'gurls']]],
  ['normzscore',['NormZScore',['../d5/dec/classgurls_1_1_norm_z_score.html',1,'gurls']]]
];
