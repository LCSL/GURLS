var searchData=
[
  ['mattype',['matType',['../d3/dfe/classgurls_1_1_opt_matrix_base.html#a0c70f9146433e3a823cb3d36f8f8b3f1',1,'gurls::OptMatrixBase']]],
  ['max_5fprintable_5fsize',['MAX_PRINTABLE_SIZE',['../db/d4e/namespacegurls.html#a11d0fc7949708ef68897305433953b8b',1,'gurls']]],
  ['msg',['msg',['../d1/d29/classgurls_1_1g_exception.html#a11b8f8e8341d91318af8299862034cee',1,'gurls::gException']]]
];
