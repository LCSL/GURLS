var searchData=
[
  ['greater',['Greater',['../d1/d9e/classgurls_1_1g_mat2_d.html#aa7ad51e00a9f70bf08a7a122a6b419f9',1,'gurls::gMat2D']]],
  ['greatereq',['GreaterEq',['../d1/d9e/classgurls_1_1g_mat2_d.html#aacc50c932b7ad327aeec2485bf0340df',1,'gurls::gMat2D']]]
];
