var classgurls_1_1_kernel_chisquared =
[
    [ "execute", "dc/d82/classgurls_1_1_kernel_chisquared.html#aead47839053b3ff840185d5556389379", null ],
    [ "factory", "dc/d0c/classgurls_1_1_kernel.html#a502a6236b98389f61b3f0affbcf027f8", null ]
];