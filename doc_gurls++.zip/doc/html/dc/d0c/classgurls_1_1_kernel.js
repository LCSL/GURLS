var classgurls_1_1_kernel =
[
    [ "execute", "dc/d0c/classgurls_1_1_kernel.html#a22ac3370b49808c62ebd100f7a964f0a", null ],
    [ "factory", "dc/d0c/classgurls_1_1_kernel.html#a502a6236b98389f61b3f0affbcf027f8", null ]
];