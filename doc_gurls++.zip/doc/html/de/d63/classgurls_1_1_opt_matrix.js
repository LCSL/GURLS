var classgurls_1_1_opt_matrix =
[
    [ "ValueType", "de/d63/classgurls_1_1_opt_matrix.html#a497597d7d340e396a2a111a2e6c2f680", null ],
    [ "MatrixType", "d3/dfe/classgurls_1_1_opt_matrix_base.html#a6af16d68562e1aaa340c96bc43403efc", null ],
    [ "OptMatrix", "de/d63/classgurls_1_1_opt_matrix.html#ae12a99ebd4b22d732265a831bfd7232e", null ],
    [ "OptMatrix", "de/d63/classgurls_1_1_opt_matrix.html#aafac47a311657b4bd610e2ee11dec471", null ],
    [ "~OptMatrix", "de/d63/classgurls_1_1_opt_matrix.html#a0296b7f4abad68c2de5f7f48ef725fdd", null ],
    [ "dynacast", "de/d63/classgurls_1_1_opt_matrix.html#afcdaab9bb024c4b065db65730359264b", null ],
    [ "dynacast", "de/d63/classgurls_1_1_opt_matrix.html#ae6ff51264f2855d69c690f2f8c4a42e8", null ],
    [ "getDataID", "d5/dcc/classgurls_1_1_gurls_option.html#a431323a19e055d3153e22a1871afb50d", null ],
    [ "getMatrixType", "d3/dfe/classgurls_1_1_opt_matrix_base.html#a03a5d5a0cece057f6ea8c6f32e039dd0", null ],
    [ "getType", "d5/dcc/classgurls_1_1_gurls_option.html#a0d920a9a0956c273d2f5898de912f1a6", null ],
    [ "getValue", "de/d63/classgurls_1_1_opt_matrix.html#a686e6896611474b7dfdd09e38e64d2a6", null ],
    [ "getValue", "de/d63/classgurls_1_1_opt_matrix.html#aa21183f51397f46255824c896ce7437e", null ],
    [ "isA", "de/d63/classgurls_1_1_opt_matrix.html#a3169b55dba6331180c70f12a719c3dc2", null ],
    [ "operator<<", "de/d63/classgurls_1_1_opt_matrix.html#a79a420291332c55a5e34e3d0613498eb", null ],
    [ "operator=", "de/d63/classgurls_1_1_opt_matrix.html#af8f78f08c6b8f67fbb23a0e2ac32db64", null ],
    [ "operator=", "de/d63/classgurls_1_1_opt_matrix.html#a1ae5f6a3c2badf0c19b303416a9d3e09", null ],
    [ "setValue", "de/d63/classgurls_1_1_opt_matrix.html#a6d51b77697ed425ed61f0251a05b395e", null ],
    [ "operator<<", "d5/dcc/classgurls_1_1_gurls_option.html#ab8ca962235eb774ea2c322df52f50afd", null ],
    [ "matType", "d3/dfe/classgurls_1_1_opt_matrix_base.html#a0c70f9146433e3a823cb3d36f8f8b3f1", null ],
    [ "type", "d5/dcc/classgurls_1_1_gurls_option.html#aea0687b6adb753e8693061721142905d", null ],
    [ "value", "de/d63/classgurls_1_1_opt_matrix.html#af5a34c78712b7a6baa7c89c6e4c78951", null ]
];