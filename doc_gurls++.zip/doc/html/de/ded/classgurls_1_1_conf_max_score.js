var classgurls_1_1_conf_max_score =
[
    [ "execute", "de/ded/classgurls_1_1_conf_max_score.html#a0c726881441f3ab0b428827e3b204153", null ],
    [ "factory", "da/d7d/classgurls_1_1_confidence.html#af86adf5cf4608cf95056029e6f979500", null ]
];