var classgurls_1_1_r_l_s_pegasos =
[
    [ "execute", "df/d7d/classgurls_1_1_r_l_s_pegasos.html#abea24119ca7cd331259533f1cd2ca06e", null ],
    [ "factory", "d6/ddf/classgurls_1_1_optimizer.html#a9470360032168e3208f4aa0c1ee05e86", null ]
];