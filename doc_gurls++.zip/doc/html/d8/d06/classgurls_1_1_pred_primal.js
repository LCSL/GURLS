var classgurls_1_1_pred_primal =
[
    [ "execute", "d8/d06/classgurls_1_1_pred_primal.html#a0daf1932d11aa14d9ae31e7233bac93f", null ],
    [ "factory", "d7/d57/classgurls_1_1_prediction.html#a1ddacf8a2757aab38d1e4b564526571a", null ]
];