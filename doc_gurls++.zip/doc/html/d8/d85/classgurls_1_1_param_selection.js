var classgurls_1_1_param_selection =
[
    [ "execute", "d8/d85/classgurls_1_1_param_selection.html#a7e30ec359410bbc97d603ceb29699eb7", null ],
    [ "factory", "d8/d85/classgurls_1_1_param_selection.html#a627e4fd41fa3c581c8eac309c32fc29e", null ]
];