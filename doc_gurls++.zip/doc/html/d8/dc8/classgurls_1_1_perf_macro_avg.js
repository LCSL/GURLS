var classgurls_1_1_perf_macro_avg =
[
    [ "execute", "d8/dc8/classgurls_1_1_perf_macro_avg.html#ae64d89229258f53c638c4518e54617b1", null ],
    [ "factory", "d5/dac/classgurls_1_1_performance.html#af45e9e3b96f97d345c8c8b8ff9e92552", null ],
    [ "macroavg", "d8/dc8/classgurls_1_1_perf_macro_avg.html#a9b6c4cebbfc043f647a4fd8456c1e5ab", null ]
];