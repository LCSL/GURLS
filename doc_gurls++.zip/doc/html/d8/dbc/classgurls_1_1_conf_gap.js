var classgurls_1_1_conf_gap =
[
    [ "execute", "d8/dbc/classgurls_1_1_conf_gap.html#a0051c2fce89f240db1ab11134223dc83", null ],
    [ "factory", "da/d7d/classgurls_1_1_confidence.html#af86adf5cf4608cf95056029e6f979500", null ]
];