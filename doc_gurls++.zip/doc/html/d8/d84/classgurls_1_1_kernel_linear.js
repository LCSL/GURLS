var classgurls_1_1_kernel_linear =
[
    [ "execute", "d8/d84/classgurls_1_1_kernel_linear.html#a482b9e5aa98a384ad24722517de29e56", null ],
    [ "factory", "dc/d0c/classgurls_1_1_kernel.html#a502a6236b98389f61b3f0affbcf027f8", null ]
];