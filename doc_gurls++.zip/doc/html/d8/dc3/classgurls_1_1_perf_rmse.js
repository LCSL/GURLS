var classgurls_1_1_perf_rmse =
[
    [ "execute", "d8/dc3/classgurls_1_1_perf_rmse.html#a6d10892a73810c81fb73cd0817518e9f", null ],
    [ "factory", "d5/dac/classgurls_1_1_performance.html#af45e9e3b96f97d345c8c8b8ff9e92552", null ]
];