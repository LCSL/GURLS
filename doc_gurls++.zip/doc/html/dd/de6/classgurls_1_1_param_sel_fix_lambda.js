var classgurls_1_1_param_sel_fix_lambda =
[
    [ "execute", "dd/de6/classgurls_1_1_param_sel_fix_lambda.html#a7d05ba3060300c445065d516942bcb61", null ],
    [ "factory", "d8/d85/classgurls_1_1_param_selection.html#a627e4fd41fa3c581c8eac309c32fc29e", null ]
];