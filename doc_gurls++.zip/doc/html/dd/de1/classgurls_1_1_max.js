var classgurls_1_1_max =
[
    [ "operator()", "dd/de1/classgurls_1_1_max.html#a4135b400410050a4039e15ae903a81d0", null ],
    [ "operator()", "dd/de1/classgurls_1_1_max.html#a1421ca0290fff437e8d8ede3ea46a7dc", null ]
];